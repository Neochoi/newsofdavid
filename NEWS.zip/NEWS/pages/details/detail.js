// pages/details/detail.js
Page({
  data:{
    id:'1523074607635'
    
  },

  onLoad(options){
    let id = options.newsId//获取传递过来的参数名，newsId是传递时命名的变量
    this.setData({
      id:id//onLoad的同事重新赋值给data
    })

    wx.request({
      url: 'https://test-miniprogram.com/api/news/detail/',
      data:{
        id:'1523074607635'
      },
      success: res=>{//获取记过的内容
        let result = res.data.result
        console.log(result)
        let title = result.title
        let source = result.source
        let date = result.date.substring(0,10)
        let readCount = result.readCount
        let content = result.content[0]
        console.log(content)
        this.setData({
          title: title,
          source:source,
          date: date,
          readCount: readCount,
          content: content,
          
        })
      },
    })
  }, 
})