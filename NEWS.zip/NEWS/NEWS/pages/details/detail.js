// pages/details/detail.js
Page({
  data:{
    detailid:'1523074607635'
    
  },

  onLoad(options){
    let detailId= options.newsId//获取传递过来的参数名，newsId是传递时命名的变量
    this.setData({
      id:detailId//onLoad的同事重新赋值给data
    })

    wx.request({
      url: 'https://test-miniprogram.com/api/news/detail/',
      data:{
        id:this.data.id
      },
      success: res=>{//获取记过的内容
        let result = res.data.result
        
        let title = result.title
        let source = result.source
        let date = result.date.substring(0,10)
        let readCount = result.readCount
        let content = result.content
        console.log(content)
        this.setData({
          title: title,
          source:source,
          date: date,
          readCount: readCount,
          content: content,
          
        })
      },
    })
  }, 
})