//index.js
//获取应用实例
// const app = getApp()

const whichnews = {
  'gn': '国内',
  'gj': '国际',
  'cj': '财经',
  'yl': '娱乐',
  'js': '军事',
  'ty': '体育',
  'other': '其他'
}

Page({

  data: {
    title: '',
    date: ' ',
    firstImage: '',
    source:'',
    newslist: [],
    currentNewsType: 'gj',
    newsmeans: whichnews,
  },
  onPullDownRefresh() {
    this.getNews(() => {
      wx.stopPullDownRefresh()
    })
  },
  onLoad() {
    this.getNews()
    // 调用函数
  },
  getNews(callback) {
    // 该函数的作用为获得数据
    wx.request({
      url: 'https://test-miniprogram.com/api/news/list/', //接口格式省略了"?type="
      data: {
        type: this.data.currentNewsType,//传入参数
      },
      success: res => {
        let result = res.data.result[0]
        // console.log(result.length)
        console.log(result)
        let title = result.title
        let date = result.date.substring(0,10)
        let source = result.source
        let image = result.firstImage
        
        let headid = result.id

        console.log(headid)
        

        let resultList = res.data.result
        let newslist = []

        for (let i = 1; i < resultList.length; i += 1) {
          newslist.push({
            listdate: resultList[i].date.substring(0,10),
            listtitle: resultList[i].title,
            listsource: resultList[i].source,
            listfirstImage: resultList[i].firstImage ? resultList[i].firstImage : '/images/timg.png',
            listid: resultList[i].id,
            
          })
        }
        console.log(newslist)
        this.setData({
          title: title,
          date: date,
          firstImage: image,
          source: source,
          newslist: newslist,
          headid: headid,
        })
        

      },
      complete: () => {//默认为不执行，当有回调函数时候回执行
        callback && callback()
      }
    })
  },
  toChangecontent(e) {
    const {cat} = e.currentTarget.dataset;
    console.log(cat)
  
  },
  toDetail(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/details/detail?newsId=${id}`//传递参数‘id’，赋值给newsId
    })
  },
})
